package me.earth.havoxrestart;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

/**
 * Author 3arthqu4ke
 * 8/23/2022
*/

public class Main {
    private static volatile boolean _running = true;
    private static volatile Process _process;

    public static void main(String[] args)
        throws IOException, InterruptedException {
        try {
            run();
        } finally {
            Process process = _process;
            if (process != null && process.isAlive()) {
                shutDownProcess(process);
            }

            _running = false;
        }
    }

    private static void run() throws IOException, InterruptedException {
        int seconds = Integer.parseInt(System.getProperty("havox.delay", "21600"));
        System.out.println("Welcome to HAV0XRestart!");
        System.out.println("Please type in the command to launch HeadlessMc.");
        System.out.println("HAV0XRestart will pipe your inputs to the process you started like this.");
        System.out.println("Every " + (seconds / 3600.0) + " hours HAV0XRestart will send a quit command to that process and repeat your command after one minute.");

        try (Scanner scanner = new Scanner(System.in)) {
            String line;
            while ((line = scanner.nextLine()) != null) {
                Process process = _process;
                if ("quit".equalsIgnoreCase(line) || "exit".equalsIgnoreCase(line)) {
                    if (process != null && process.isAlive()) {
                        shutDownProcess(process);
                    }

                    System.exit(0);
                } else {
                    if (process != null) {
                        if (process.isAlive()) {
                            write(process, line);
                            continue;
                        }

                        System.err.println("Process is not alive!");
                        System.exit(0);
                        return;
                    }

                    System.out.println("Using " + line + " to launch Minecraft!");
                    StringTokenizer st = new StringTokenizer(line);
                    String[] cmdarray = new String[st.countTokens()];
                    for (int i = 0; st.hasMoreTokens(); i++) {
                        cmdarray[i] = st.nextToken();
                    }

                    _process = new ProcessBuilder()
                        .command(cmdarray)
                        .redirectOutput(ProcessBuilder.Redirect.INHERIT)
                        .redirectError(ProcessBuilder.Redirect.INHERIT)
                        .start();
                    Thread thread = new Thread(() -> {
                        try {
                            while (_running) {
                                _process.waitFor(seconds, TimeUnit.SECONDS);
                                if (!_process.isAlive()) {
                                    System.out.println("Process has been shut down!");
                                    System.exit(0);
                                    return;
                                }

                                shutDownProcess(_process);
                                if (_running) {
                                    System.out.println("Restarting process with " + Arrays.toString(cmdarray));
                                    _process = new ProcessBuilder().command(cmdarray)
                                                                   .redirectOutput(ProcessBuilder.Redirect.INHERIT)
                                                                   .redirectError(ProcessBuilder.Redirect.INHERIT)
                                                                   .start();
                                }
                            }
                        } catch (InterruptedException | IOException e) {
                            e.printStackTrace();
                            System.exit(-1);
                        }
                    });
                    thread.setDaemon(true);
                    thread.start();
                }
            }
        }
    }

    private static void write(Process process, String command) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()))) {
            bw.write(command);
            bw.newLine();
        }
    }

    private static void shutDownProcess(Process process) throws InterruptedException, IOException {
        if (!process.isAlive()) {
            return;
        }

        System.out.println("Attempting to shut down process...");
        write(process, "quit");
        process.waitFor(60L, TimeUnit.SECONDS);
        if (process.isAlive()) {
            System.err.println("Process is still alive after one minute, killing it!");
            process.destroy();
        }
    }

}
